<?php 
include("../config.php"); 

header('Content-Type: text/html; charset=utf-8');

  
 $email = strip_tags(trim($_POST["email"]));
  
$sql_query = "SELECT * FROM Users WHERE Email LIKE '$email' "; 
$result_Users = $conn->query($sql_query);
		while($row = $result_Users->fetch_assoc()) {				    
			$username = $row['UserName'];
			//$pass = $row['Password'];
			$Emailrow = $row['Email'];
			$AVLink = $row['Avatar'];
		    }


if ($email == $Emailrow){

$NewPass = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz"), 0, 5);
$md5Pass = md5($NewPass);
	$sqlPass = "UPDATE Users SET Password='$md5Pass' WHERE Email LIKE '$email'";
	$conn->query($sqlPass);

	$imgAvatar = "https://www.yourSite/Images/".$AVLink;
 
require("PHPMailer/class.phpmailer.php");
			
$mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$mail->IsSMTP();
$mail->Host = "smtp.flockmail.com";
$mail->SMTPAuth = true;
$mail->Username = "info@novbook.net";
$mail->Password = "باسوورد الايميل";
$mail->From = "info@novbook.net";
$mail->SMTPSecure = "tls";
$mail->Port = 587;
$mail->FromName = "info@novbook.net";
$mail->AddAddress("{$email}");
$mail->WordWrap = 50;
$mail->IsHTML(true);
            
$mail->Subject = "استعادة كلمة المرور";
$mail->Body    = "
<table border='0' width='50%' cellspacing='0' cellpadding='0'>
<tr>
	<td align='center'>
	
<p>&nbsp;</p>
<table border='0' width='75%' cellspacing='1' style='border-collapse: collapse' bordercolor='#FF9900' bgcolor='#EFEFF4'>
<tr>
	<td colspan='2'>
	<p align='center'>
<img src='{$imgAvatar}' style='width: 150px; height: 150px; border-radius: 50%; border-color: #fff; border-width: 5px;'></td>
</tr>
<tr>
	<td align='center' width='100%' colspan='2'>
	<font size='4'>مرحباً <font color='orange'>{$username}<br>
	</font>استعادة البيانات من تطبيق  <br><a href='https://www.yourSite'>قواعد البيانات MySql</a></font></td>
</tr>
<tr>
	<td align='left' width='50%'><b>&nbsp; اسم المستخدم &nbsp;</b></td>
	<td align='right' width='50%'><p align='right'><b><span lang='ar-om'>&nbsp; <font color='red'>{$username}</font>  &nbsp; </span>
	</b></td>
</tr>
<tr>
	<td align='left' width='50%'><b>&nbsp; كلمة المرور &nbsp;</b></td>
	<td align='right' width='50%'><p align='right'><b><span lang='ar-om'>&nbsp; <font color='red'>{$NewPass}</font>  &nbsp; </span>
	</b></td>
</tr>

<br>
<br>
<tr></td>
<p><span style='font-size: 12px; '>
<a href='https://www.yourSite'>مع تحيات فريق العمل</a>  </span></p>
<br>
</td></tr>

</td>
</tr>
</table>
</td>
</tr>
</table>

";


			if(!$mail->Send())
			{
			   $check = "Send_Error";   			
			   echo "Mailer Error: " . $mail->ErrorInfo;
			   exit;
			}else{
				$check = "Send_OK";       
			}

}else{
$check = "No_Email";    
}

  $json_re=array();
	array_push($json_re,array("success"=>$check));
    echo json_encode($json_re);   

?> 
  